CRYPTOCALC WEBSITE UPGRADE

UPLOAD
1. Open https://github.com/Naeemjanu/cryptocalc
2. Add file -> Upload files.
3. Extract this ZIP on your computer.
4. Upload index.html, about.html, contact.html, privacy.html, terms.html and disclaimer.html directly into the repository root.
5. Commit changes to main. Wait for GitHub Pages to redeploy.

PAGES
https://naeemjanu.github.io/cryptocalc/
https://naeemjanu.github.io/cryptocalc/about.html
https://naeemjanu.github.io/cryptocalc/contact.html
https://naeemjanu.github.io/cryptocalc/privacy.html
https://naeemjanu.github.io/cryptocalc/terms.html
https://naeemjanu.github.io/cryptocalc/disclaimer.html

GOOGLE ANALYTICS
1. Create a GA4 property and Web data stream for https://naeemjanu.github.io/cryptocalc/
2. Copy the Measurement ID starting G-.
3. Open index.html in a text editor. Find GOOGLE ANALYTICS.
4. Uncomment the GA4 code and replace G-XXXXXXXXXX in both places with your actual ID.
5. Save and upload the updated index.html. Check Reports -> Realtime. Data collection may take up to 30 minutes to begin.

ADS
Ad spaces are placeholders, not live ads. Apply at https://www.google.com/adsense/start/ and follow the current site review process. Ads cannot show until approval.
After approval, add the exact AdSense code Google supplies. If Google asks for ads.txt, publish the exact line provided in your account.
Never click your own ads, encourage clicks, or buy fake traffic.

BEFORE APPLYING
- Replace the Contact page placeholder with a real monitored email address.
- Replace the owner placeholder on About with your real name/business name.
- Customize the privacy, terms and disclaimer pages to accurately reflect your actual practices and local legal requirements. These are starter templates, not legal advice.
- Add genuinely useful original educational content; a calculator alone may not be enough to demonstrate a valuable site.
- Implement legally required cookie/consent controls before enabling analytics or personalized ads, where applicable.

LIMITATIONS
The calculator uses user-entered values and simplified calculations. It does not fetch live prices, connect to exchanges, execute trades or calculate exchange-specific liquidation. Funding, slippage, contract rules and actual fees can differ.
