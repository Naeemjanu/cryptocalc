CRYPT0CALC — WEBSITE UPDATE

FILES INCLUDED
- Trading calculator and educational guide index
- Six focused educational guides and calculator methodology
- About, Contact, Privacy Policy, Terms and Disclaimer pages
- robots.txt and sitemap.xml

CONTACT
The Contact page displays: muhammadnaeem784125678@gmail.com
This address will be public on your website.

PUBLISH TO GITHUB PAGES
1. Open https://github.com/Naeemjanu/cryptocalc
2. Upload ALL files from this folder directly into the repository root (not inside another folder).
3. Commit the changes to the main branch.
4. Wait for GitHub Pages to deploy, then visit https://naeemjanu.github.io/cryptocalc/

BEFORE APPLYING TO ADSENSE
- Read every page and correct anything that does not match your actual practices.
- Add your own original examples, screenshots or explanations where they genuinely help readers. Do not publish content you have not checked.
- The privacy page currently states that analytics and third-party ads are not intentionally active. Update it if you add either service.
- No Google Analytics or AdSense scripts are active. Add only the exact code Google supplies after your account/site setup.
- Do not invent an ads.txt line. Add it only if Google provides the exact publisher record.
- Do not click your own ads, ask others to click them, buy fake traffic or use traffic-exchange services.
- Check Google's current publisher policies and consent requirements for your audience and location.

IMPORTANT LIMITATIONS
- The calculator uses simplified estimates. It does not fetch live prices, connect to exchanges, execute trades or calculate exchange-specific liquidation.
- No website change can guarantee AdSense approval. Google reviews the complete site, content quality, navigation, policy compliance and traffic quality.
- These pages are general education, not financial, investment, tax or legal advice.
